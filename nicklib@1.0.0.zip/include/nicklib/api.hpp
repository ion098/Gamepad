#pragma once

#include "nicklib/button.hpp"
#include "nicklib/gamepad.hpp"