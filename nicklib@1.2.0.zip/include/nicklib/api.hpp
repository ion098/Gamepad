#pragma once

#include "nicklib/gamepad.hpp"